const static_vars={
    player_count:3,
    rols:[
        "citizen",
        "citizen",
        "detective",
        "rifleman",
        "commando",
        "guard",
        "nato",
        "hostage_taker",
        "doctor",
        "godfather",
    ],
    speech_time:{
        introduction:10,
        turn:15,
        challenge:15,
        defence:30,
        chaos:10,
        final_words:20
    },
    scenario:"nato",
    to_dec:"price"
}

module.exports=static_vars