const static={
    url:"http://192.168.43.161:4090"
}

module.exports=static