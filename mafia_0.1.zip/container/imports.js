const imports = {
    registion: require("../routs/registion"),
    user: require("../routs/user"),
    admin: require("../routs/admin"),
    items:require("../routs/items"),
    channel:require("../routs/channel"),
    report:require("../routs/report"),
}

module.exports=imports